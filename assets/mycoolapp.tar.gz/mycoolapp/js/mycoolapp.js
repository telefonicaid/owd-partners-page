'use strict';

var MyCoolApp = {
  //List of HTML5 + CSS3 feature to test
  CAPABILITIES: [
    'localstorage',
    'canvas',
    'applicationcache',
    'borderradius',
    'postmessage',
    'indexeddb',
    'boxshadow'
  ],

  /**
    Initialises the webpage
  */
  init: function _init() {
    this.checkCapabilities();
    this.checkConnectivity();
    this.checkApplication();
  },
  
  /**
    Fill the list with capabilities detected
    with modernizr
  */
  checkCapabilities: function _checkCapabilities() {
    var elem;
    this.CAPABILITIES.forEach(function(feature){
      elem = document.getElementById(feature);
      elem.innerHTML = Modernizr[feature] ? 'yes' : 'no';
      elem.className = elem.innerHTML;
    });
  },
  
  /**
    Check whenever the connection is enabled or not
  */
  checkConnectivity: function _checkConnectivity() {
    var changeStatus = function() {
      document.getElementById('connection').innerHTML = navigator.onLine ? 'online' : 'offline';
      document.getElementById('connection').className = navigator.onLine ? 'yes' : 'no';
    }
    changeStatus.call();
    //Listen to connectivity changes to update status
    window.addEventListener("offline",changeStatus);
    window.addEventListener("online",changeStatus);
    
    //But sometimes a 'true' value doesn't mean we have connection
    //To avoid effects of appcache, perform a request to one known file
    function detectConnectivity() {
      var xhr = new XMLHttpRequest();
      
      var noResponseTimer = setTimeout(function() {
        xhr.abort();
        //We can fire an event an notify listeners
        document.getElementById('connection').innerHTML = 'offline';
        document.getElementById('connection').className = 'no';
        
      }, 1000 /* Timeout milliseconds*/);
      
      xhr.onreadystatechange = function() {
        if (xhr.readyState != 4) {
              return;
        }
        
        if(xhr.status == 200) {
          //Connectivity
          //We can fire an event here
          clearTimeout(noResponseTimer)
          document.getElementById('connection').innerHTML = 'online';
          document.getElementById('connection').className = 'yes';
        } else {
          //Offline
          //We can fire an event here
          document.getElementById('connection').innerHTML = 'offline';
          document.getElementById('connection').className = 'no';
        }
      };
      
      //Perform the get to a file NOT IN THE APPCACHE
      //(in this case the manifest.webapp is not valid, replace this file)
      xhr.open('GET', 'manifest.webapp');
      xhr.send();
    };
    
    detectConnectivity.call();
  },
  
  /**
    MOZILLA ONLY: Checks for the Open Web Apps api
    to show the link to install or show information
    about installation
  */
  checkApplication: function _checkApplication() {
    if(navigator.mozApps) {
      var apps = document.getElementById('apps');
      var req = window.navigator.mozApps.getSelf();
      req.onsuccess = function(e) {
        //Show information regarding the app
        
        var span = document.createElement('span');
        span.innerHTML = 'Congrats, this app is already installed!';
        span.className = 'install';
        apps.appendChild(span);
        
        //Date installed
        var dl = document.createElement('dl');
        var dt = document.createElement('dt');
        var dd = document.createElement('dd');
        dd.className = 'yes';
        
        dt.innerHTML = 'Date installed';
        dd.innerHTML = new Date(req.result.installTime * 1000);
        
        dl.appendChild(dt);
        dl.appendChild(dd);
        
        //Origin
        dt = document.createElement('dt');
        dd = document.createElement('dd');
        dd.className = 'yes';
        
        dt.innerHTML = 'Origin';
        dd.innerHTML = req.result.origin;
        
        dl.appendChild(dt);
        dl.appendChild(dd);
        
        //Description
        dt = document.createElement('dt');
        dd = document.createElement('dd');
        dd.className = 'yes';
        
        dt.innerHTML = 'Description';
        dd.innerHTML = req.result.manifest.description;
        
        
        dl.appendChild(dt);
        dl.appendChild(dd);
        
        apps.appendChild(dl);
      };
      req.onerror = function(e) {
        //Show the install button
        var span = document.createElement('span');
        span.innerHTML = 'Click me to install';
        span.className = 'install';
        span.addEventListener('click', function(){
          navigator.mozApps.install('manifest.webapp');
        });
        apps.appendChild(span);
      };
      
      apps.className = '';
    }
  }
};

MyCoolApp.init();

